from django.db import models
from django.contrib.auth.models import AbstractUser
from datetime import date
# Create your models here.


class CustomUser(AbstractUser):
    FirstName = models.CharField(max_length=30, unique=True)
    LastName = models.CharField(max_length=30)
    email = models.EmailField(unique=True)
    def save(self, *args, **kwargs):
        # Set the username to the value of FirstName
        self.username = self.FirstName.lower()  # You can customize this logic if needed
        super().save(*args, **kwargs)

    def __str__(self):
        return self.username




class Category(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    CategoryName = models.CharField(default='Studies',max_length=10)
    Color = models.CharField(default='black',max_length=10)
    def __str__(self):
        return self.CategoryName+'---'+self.user.username

class Todo(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    date_created = models.DateField(auto_now_add=True)
    due_date = models.DateField(default=date.today().strftime('%Y-%m-%d'))
    Title = models.CharField(max_length=50) 
    Description = models.CharField(default='Default Description', max_length=150)
    Category = models.ForeignKey(Category, on_delete=models.CASCADE)
    
    Progress = models.CharField(default='Incomplete', max_length=15)
    isDone = models.BooleanField(default=False)
    isUrgent = models.BooleanField(default=False)
    #Pour la corbeille et la modification des Taches:
    is_in_recycle_bin = models.BooleanField(default=False)

   
    def __str__(self):
        return self.user.username+' || '+str(self.id) + '    ||    ' + self.Title + '    ||    ' + 'Descr...' + '    ||    ' + self.Progress + '    ||    Date Created:' + str(self.date_created) + '    ||    Due Date:' + str(self.due_date)



