from django.urls import path,include
from . import views
from .views import SignUpView, LoginView

#URLConf
urlpatterns = [
    path('Accueil/', views.Accueil, name='Accueil'),
    path('Accueil/Auth/signup', SignUpView.as_view(), name='signup'),
    path('Accueil/Auth/login', LoginView.as_view(), name='login'),

    path('Calendar/', views.Calendar2, name='calendar2'),
    path('Calendar/<int:year>/<int:month>/<int:day>/', views.Dashboard, name='Calendar'),
    path('Calendar/TodoList/', views.TodoList, name='TodoList'),


    path('api/fetch-items/', views.fetch_items, name='fetch_items'),
    path('api/create-item/', views.create_item, name='create_item'),
    path('api/update-item/<int:item_id>/', views.update_item, name='update_item'),
    path('api/delete-item/<int:item_id>/', views.delete_item, name='delete_item'),



]