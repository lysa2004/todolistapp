from django.shortcuts import render,redirect
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
#from .models import List,Todo,DeletedTask,ModificationHistory
from django.http import JsonResponse   
import json 
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required


import datetime
from .models import CustomUser, Todo ,Category
from django.contrib.auth.forms import AuthenticationForm
from django.urls import reverse
from django.views.generic import CreateView, FormView
from .forms import CustomUserCreationForm,CustomAuthenticationForm
from django.views.decorators.http import require_http_methods


# Create your views here.


# Registration view
class SignUpView(CreateView):
    model = CustomUser
    form_class = CustomUserCreationForm
    template_name = 'registration/signup.html'
    
    def get_success_url(self):
        today = datetime.datetime.now().date()
        url = reverse('Calendar', args=(today.year, today.month, today.day))
        return url
    
    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)  # Log in the user
        return response


# Login view
class LoginView(FormView):
    form_class = CustomAuthenticationForm
    template_name = 'registration/login.html'

    def get_success_url(self):
        today = datetime.datetime.now().date()
        url = reverse('Calendar', args=(today.year, today.month, today.day))
        return url

    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, form.get_user())  # Log in the user
        return response







@login_required
@require_http_methods(["GET"])
def fetch_items(request):
    items = Todo.objects.filter(user=request.user)
    data = [{'id': item.id, 'Title': item.Title,'Description':item.Description,'Category':item.Category.CategoryName,'isUrgent':item.isUrgent,'isDone':item.isDone} for item in items]
    return JsonResponse(data, safe=False)

@login_required
@require_http_methods(["POST"])
def create_item(request):
    # Extract data from the POST request
    data = json.loads(request.body)
    newTaskTitle = data.get('title')
    newTaskCategory = data.get('category')
    newTaskImportance = data.get('important')
    newTaskDueDate = data.get('dueDate')

    Color = 'black'
    # Create a new item
    # res = AddNewList(request,newTaskCategory,Color)
    category = Category.objects.get_or_create(user=request.user, CategoryName=newTaskCategory, defaults={'Color': Color})
    new_item = Todo.objects.create(user=request.user, Title=newTaskTitle, due_date=newTaskDueDate ,isUrgent=newTaskImportance, Category=category[0])
    # Return the new item's data
    data2 = {'id': new_item.id, 'title': new_item.Title}
    return JsonResponse(data2)

@login_required
@require_http_methods(["PUT"])
def update_item(request, item_id):

    item = Todo.objects.get(user=request.user, id=item_id)
    # Extract data from the PUT request
    data = json.loads(request.body)

    # Update the item
    if len(data) > 1:
        title = data.get('Title')
        category = data.get('Category')
        item.Title = title
        category_obj = Category.objects.get_or_create(user=request.user, CategoryName=category)
        item.Category = category_obj[0]
    else:        
        is_done = data.get('isDone')
        item.isDone = is_done
    # save it
    item.save()

    # Return the updated item's data
    data = {'id': item.id, 'Title': item.Title, 'Category': item.Category.CategoryName, 'isDone':item.isDone}
    return JsonResponse(data)

@login_required
@require_http_methods(["DELETE"])
def delete_item(request, item_id):
    item = Todo.objects.get(user=request.user, id=item_id)
    item.delete()
    return JsonResponse({'message': 'Item deleted successfully'})










def Accueil(request):

    return render(request,'accueil.html',{})

def Auth(request):
    
    return render(request,'registration/login.html',{})

@login_required
def Dashboard(request, year, month, day): 
    calendar_date = str(year)+'-'+str(month)+'-'+str(day)
    Tasks = Todo.objects.filter(user=request.user,due_date=calendar_date)

    return render(request, 'callendrier.html',{'Tasks':Tasks,})

from django.core.serializers import serialize

@login_required
def TodoList(request):
    
    AllTasks = Todo.objects.filter(user=request.user)
    tasks_json = serialize('json', AllTasks)
    context = {
        'username':request.user.username,
        'tasks': tasks_json
    }
    return render(request, 'todolist.html',context)



@login_required
def Calendar2(request): 
    

    return render(request, 'callendrier2.html')